'''This modulo implements the modulo(x,n) = x%n'''
def modulo(x,n):
	return x - (n*(x/n))